export const inandout = (value) => {
  return {
    type: 'INANDOUT',
    payload: value,
  }
}
