export const connectionAction = (value) => {
  return {
    type: 'CONNECTED',
    payload: value,
  }
}
