# StackingDashboard

Pre-requisite

```
npm install
```
To run the app

```
npm run start
```



Contract Addresses : 

YFDAI Goerli Token Address : 0x0e575098fdd852ed68ed7ed28c04f8324da186d8

YFDAI Goerli NFT Address : 0x0532Ed56b02B5FAE50D47913105a774aB0b392D1

YFDAI Goerli Staking Address : 0xb1d3056c353149391a00611af78af90aba90aa4b

SSGT Matic NFT Address : 0xa3E11A801e20C7C1C8a6Ce95032163991218623b

SSGT Matic Staking Address : 0xa3E11A801e20C7C1C8a6Ce95032163991218623b

SSGT Matic Token Address : 0x2a881131c3f8f825e74757eb5792fa12a162d878